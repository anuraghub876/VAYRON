@echo off
echo VAYRON server start ho raha hai...
echo Browser me kholo: http://localhost:5000
node server.js
pause
