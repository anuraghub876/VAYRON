const { readDB, writeDB } = require("../lib/db");
const { ApiError } = require("../lib/http");
const { clean } = require("../lib/sanitize");

// GET /api/products/:id/reviews — public
async function getProductReviews({ params }) {
  const db = readDB();
  const productId = Number(params.id);

  return db.reviews
    .filter((r) => r.productId === productId)
    .sort((a, b) => b.id - a.id);
}

// POST /api/products/:id/reviews — customer only
async function addReview({ user, params, body }) {
  const db = readDB();
  const productId = Number(params.id);

  const product = db.products.find((p) => p.id === productId);
  if (!product) throw new ApiError(404, "Product not found");

  const rating = Number(body.rating);
  if (!(rating >= 1 && rating <= 5)) {
    throw new ApiError(400, "Rating must be between 1 and 5");
  }

  const text = clean(body.text, 600);

  // Ek customer ek product pe sirf ek review de sakta hai (dobara de to update ho jaata hai)
  const existing = db.reviews.find(
    (r) => r.productId === productId && r.customerId === user.id
  );

  const customer = db.customers.find((c) => c.id === user.id);

  if (existing) {
    existing.rating = rating;
    existing.text = text;
    existing.updatedAt = new Date().toISOString();
  } else {
    db.reviews.push({
      id: db.nextIds.review++,
      productId,
      sellerId: product.sellerId,
      customerId: user.id,
      customerName: customer ? customer.name : "Customer",
      rating,
      text,
      createdAt: new Date().toISOString(),
    });
  }

  writeDB(db);

  return { message: existing ? "Review updated" : "Review submitted", review: existing || db.reviews[db.reviews.length - 1] };
}

module.exports = { getProductReviews, addReview };
