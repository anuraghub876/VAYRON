const { readDB } = require("../lib/db");
const { ApiError } = require("../lib/http");

async function sellerProfile({ user }) {
  const db = readDB();
  const seller = db.sellers.find((s) => s.id === user.id);
  if (!seller) throw new ApiError(404, "Seller not found");

  const { password, ...safe } = seller;
  return safe;
}

async function sellerOrders({ user }) {
  const db = readDB();
  const myProductIds = db.products.filter((p) => p.sellerId === user.id).map((p) => p.id);

  return db.orders
    .map((order) => {
      const customer = db.customers.find((c) => c.id === order.customerId);
      return {
        ...order,
        customerName: customer ? customer.name : 'Customer #' + order.customerId,
        items: order.items.filter((i) => myProductIds.includes(i.productId)),
      };
    })
    .filter((o) => o.items.length > 0)
    .sort((a, b) => b.id - a.id);
}

async function sellerStats({ user }) {
  const db = readDB();
  const myProducts = db.products.filter((p) => p.sellerId === user.id);
  const myProductIds = myProducts.map((p) => p.id);

  let totalSales = 0;
  let totalOrders = 0;

  db.orders.forEach((order) => {
    const relevantItems = order.items.filter((i) => myProductIds.includes(i.productId));
    if (relevantItems.length) {
      totalOrders++;
      totalSales += relevantItems.reduce((s, i) => s + i.price * i.quantity, 0);
    }
  });

  return {
    totalProducts: myProducts.length,
    approvedProducts: myProducts.filter((p) => p.status === "approved").length,
    pendingProducts: myProducts.filter((p) => p.status === "pending").length,
    totalOrders,
    totalSales,
  };
}

module.exports = { sellerProfile, sellerOrders, sellerStats };
