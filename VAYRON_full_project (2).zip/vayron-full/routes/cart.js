const { readDB, writeDB } = require("../lib/db");
const { ApiError } = require("../lib/http");

async function getCart({ user }) {
  const db = readDB();
  return db.carts[user.id] || [];
}

async function addToCart({ user, body }) {
  const { productId, size, color, quantity } = body;
  const db = readDB();

  const product = db.products.find((p) => p.id === Number(productId));
  if (!product) throw new ApiError(404, "Product not found");

  if (!db.carts[user.id]) db.carts[user.id] = [];
  const cart = db.carts[user.id];

  const existing = cart.find(
    (i) => i.productId === product.id && i.size === size && i.color === color
  );

  if (existing) {
    existing.quantity += Number(quantity) || 1;
  } else {
    cart.push({
      productId: product.id,
      name: product.name,
      img: product.img,
      price: product.price,
      old: product.old,
      store: product.store,
      size: size || "M",
      color: color || "",
      quantity: Number(quantity) || 1,
    });
  }

  writeDB(db);
  return cart;
}

async function updateCartItem({ user, params, body }) {
  const { quantity, size, color } = body;
  const db = readDB();
  const cart = db.carts[user.id] || [];

  const item = cart.find(
    (i) =>
      i.productId === Number(params.productId) &&
      (!size || i.size === size) &&
      (!color || i.color === color)
  );

  if (!item) throw new ApiError(404, "Item not in cart");

  item.quantity += Number(quantity);
  db.carts[user.id] = item.quantity <= 0 ? cart.filter((i) => i !== item) : cart;

  writeDB(db);
  return db.carts[user.id];
}

async function removeCartItem({ user, params }) {
  const db = readDB();
  db.carts[user.id] = (db.carts[user.id] || []).filter(
    (i) => i.productId !== Number(params.productId)
  );
  writeDB(db);
  return db.carts[user.id];
}

async function clearCart({ user }) {
  const db = readDB();
  db.carts[user.id] = [];
  writeDB(db);
  return [];
}

module.exports = { getCart, addToCart, updateCartItem, removeCartItem, clearCart };
