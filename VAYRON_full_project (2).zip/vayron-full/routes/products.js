const { readDB, writeDB } = require("../lib/db");
const { ApiError } = require("../lib/http");
const { clean, cleanList, cleanImg } = require("../lib/sanitize");

async function listProducts({ query }) {
  const db = readDB();
  let list = db.products.filter((p) => p.status === "approved");

  if (query.category) {
    list = list.filter((p) => p.category.toLowerCase() === query.category.toLowerCase());
  }

  if (query.search) {
    const q = query.search.toLowerCase();
    list = list.filter(
      (p) =>
        p.name.toLowerCase().includes(q) ||
        p.type.toLowerCase().includes(q) ||
        p.store.toLowerCase().includes(q)
    );
  }

  return list;
}

async function getProduct({ params }) {
  const db = readDB();
  const product = db.products.find((p) => p.id === Number(params.id));
  if (!product) throw new ApiError(404, "Product not found");
  return product;
}

async function myProducts({ user }) {
  const db = readDB();
  return db.products.filter((p) => p.sellerId === user.id);
}

async function addProduct({ user, body }) {
  const { name, type, category, price, old, img, sizes, colors, stock } = body;

  if (!name || !type || !category || !price) {
    throw new ApiError(400, "Please fill required product fields");
  }
  if (!(Number(price) > 0)) throw new ApiError(400, "Price must be greater than 0");

  const db = readDB();
  const seller = db.sellers.find((s) => s.id === user.id);

  const product = {
    id: db.nextIds.product++,
    name: clean(name),
    type: clean(type),
    category: clean(category),
    price: Number(price),
    old: Number(old) || Number(price),
    img: cleanImg(img),
    store: seller ? seller.shop : "Unknown Store",
    sellerId: user.id,
    sizes: cleanList(sizes),
    colors: cleanList(colors),
    stock: Math.max(0, Number(stock) || 0),
    status: "pending", // admin approve karega tab customer ko dikhega
  };

  db.products.push(product);
  writeDB(db);

  return { message: "Product submitted for approval", product };
}

async function updateProduct({ user, params, body }) {
  const db = readDB();
  const product = db.products.find((p) => p.id === Number(params.id));

  if (!product) throw new ApiError(404, "Product not found");
  if (product.sellerId !== user.id) throw new ApiError(403, "This is not your product");

  // Sirf ye fields seller badal sakta hai — status/id/sellerId/store kabhi nahi
  const before = JSON.stringify([product.name, product.type, product.img]);
  if (body.name !== undefined) product.name = clean(body.name);
  if (body.type !== undefined) product.type = clean(body.type);
  if (body.price !== undefined && Number(body.price) > 0) product.price = Number(body.price);
  if (body.old !== undefined) product.old = Number(body.old) || product.price;
  if (body.img !== undefined) product.img = cleanImg(body.img);
  if (body.sizes !== undefined) product.sizes = cleanList(body.sizes);
  if (body.colors !== undefined) product.colors = cleanList(body.colors);
  if (body.stock !== undefined) product.stock = Math.max(0, Number(body.stock) || 0);

  // Naam/type/photo badle to dobara admin approval chahiye
  if (before !== JSON.stringify([product.name, product.type, product.img])) {
    product.status = "pending";
  }
  writeDB(db);

  return { message: "Product updated", product };
}

async function deleteProduct({ user, params }) {
  const db = readDB();
  const idx = db.products.findIndex((p) => p.id === Number(params.id));

  if (idx === -1) throw new ApiError(404, "Product not found");
  if (db.products[idx].sellerId !== user.id) throw new ApiError(403, "This is not your product");

  db.products.splice(idx, 1);
  writeDB(db);

  return { message: "Product deleted" };
}

module.exports = { listProducts, getProduct, myProducts, addProduct, updateProduct, deleteProduct };
