const { readDB, writeDB } = require("../lib/db");
const { ApiError } = require("../lib/http");

async function placeOrder({ user, body }) {
  const { address, paymentMethod } = body;
  const db = readDB();

  const rawCart = db.carts[user.id] || [];
  if (!rawCart.length) throw new ApiError(400, "Your cart is empty");

  // Price hamesha database ke latest product se lo (cart snapshot par bharosa nahi)
  // aur stock check karo
  const cart = rawCart.map((item) => {
    const product = db.products.find((p) => p.id === item.productId);
    if (!product || product.status !== "approved") {
      throw new ApiError(400, `"${item.name}" is no longer available, please remove it from your cart`);
    }
    if (product.stock < item.quantity) {
      throw new ApiError(400, `Only ${product.stock} left in stock for "${product.name}"`);
    }
    return { ...item, price: product.price, old: product.old || product.price };
  });

  // stock ghatao
  cart.forEach((item) => {
    const product = db.products.find((p) => p.id === item.productId);
    product.stock -= item.quantity;
  });

  const itemsTotal = cart.reduce((s, i) => s + i.price * i.quantity, 0);
  const oldTotal = cart.reduce((s, i) => s + i.old * i.quantity, 0);
  const delivery = itemsTotal >= 1999 ? 0 : 49;
  const handling = 5;
  const grandTotal = itemsTotal + delivery + handling;

  const order = {
    id: db.nextIds.order++,
    customerId: user.id,
    items: cart,
    itemsTotal,
    discount: oldTotal - itemsTotal,
    delivery,
    handling,
    grandTotal,
    address: String(address || "").replace(/[<>]/g, "").slice(0, 500),
    paymentMethod: String(paymentMethod || "COD").replace(/[<>]/g, "").slice(0, 30),
    status: "Placed",
    createdAt: new Date().toISOString(),
  };

  db.orders.push(order);
  db.carts[user.id] = [];
  writeDB(db);

  return { message: "Order placed successfully", order };
}

async function myOrders({ user }) {
  const db = readDB();
  return db.orders.filter((o) => o.customerId === user.id);
}

async function getOrder({ user, params }) {
  const db = readDB();
  const order = db.orders.find(
    (o) => o.id === Number(params.id) && o.customerId === user.id
  );
  if (!order) throw new ApiError(404, "Order not found");
  return order;
}

module.exports = { placeOrder, myOrders, getOrder };
