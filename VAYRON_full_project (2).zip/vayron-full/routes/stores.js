const { readDB } = require("../lib/db");
const { ApiError } = require("../lib/http");

// GET /api/stores/:sellerId — public, full store profile
async function getStore({ params }) {
  const db = readDB();
  const sellerId = Number(params.sellerId);

  const seller = db.sellers.find((s) => s.id === sellerId);
  if (!seller) throw new ApiError(404, "Store not found");

  const products = db.products.filter(
    (p) => p.sellerId === sellerId && p.status === "approved"
  );
  const productIds = products.map((p) => p.id);

  // Is seller ke products wale saare orders dhundo
  const sellerOrders = db.orders
    .map((o) => ({
      ...o,
      items: o.items.filter((i) => productIds.includes(i.productId)),
    }))
    .filter((o) => o.items.length > 0);

  const uniqueCustomers = new Set(sellerOrders.map((o) => o.customerId));

  const reviews = db.reviews
    .filter((r) => r.sellerId === sellerId)
    .sort((a, b) => b.id - a.id);

  const avgRating = reviews.length
    ? Math.round((reviews.reduce((s, r) => s + r.rating, 0) / reviews.length) * 10) / 10
    : 0;

  return {
    seller: {
      id: seller.id,
      shop: seller.shop,
      owner: seller.owner,
      city: seller.city,
      category: seller.category,
      status: seller.status,
    },
    products,
    stats: {
      totalProducts: products.length,
      totalOrders: sellerOrders.length,
      totalCustomers: uniqueCustomers.size,
      avgRating,
      totalReviews: reviews.length,
    },
    reviews: reviews.slice(0, 20),
  };
}

module.exports = { getStore };
