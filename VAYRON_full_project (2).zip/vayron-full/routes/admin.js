const { readDB, writeDB } = require("../lib/db");
const { ApiError } = require("../lib/http");

async function allSellers() {
  const db = readDB();
  return db.sellers.map(({ password, ...s }) => s);
}

async function approveSeller({ params }) {
  const db = readDB();
  const seller = db.sellers.find((s) => s.id === Number(params.id));
  if (!seller) throw new ApiError(404, "Seller not found");

  seller.status = "Verified";
  writeDB(db);
  return { message: `${seller.shop} verified successfully`, seller };
}

async function rejectSeller({ params }) {
  const db = readDB();
  const seller = db.sellers.find((s) => s.id === Number(params.id));
  if (!seller) throw new ApiError(404, "Seller not found");

  seller.status = "Rejected";
  writeDB(db);
  return { message: `${seller.shop} rejected`, seller };
}

async function adminProducts({ query }) {
  const db = readDB();
  return query.status ? db.products.filter((p) => p.status === query.status) : db.products;
}

async function approveProduct({ params }) {
  const db = readDB();
  const product = db.products.find((p) => p.id === Number(params.id));
  if (!product) throw new ApiError(404, "Product not found");

  product.status = "approved";
  writeDB(db);
  return { message: "Product approved", product };
}

async function rejectProduct({ params }) {
  const db = readDB();
  const product = db.products.find((p) => p.id === Number(params.id));
  if (!product) throw new ApiError(404, "Product not found");

  product.status = "rejected";
  writeDB(db);
  return { message: "Product rejected", product };
}

async function adminStats() {
  const db = readDB();
  return {
    totalCustomers: db.customers.length,
    totalSellers: db.sellers.length,
    pendingSellers: db.sellers.filter((s) => s.status === "Pending Verification").length,
    totalProducts: db.products.length,
    pendingProducts: db.products.filter((p) => p.status === "pending").length,
    totalOrders: db.orders.length,
    totalRevenue: db.orders.reduce((s, o) => s + o.grandTotal, 0),
  };
}

module.exports = {
  allSellers,
  approveSeller,
  rejectSeller,
  adminProducts,
  approveProduct,
  rejectProduct,
  adminStats,
};
