const { readDB, writeDB } = require("../lib/db");
const { hashPassword, verifyPassword } = require("../lib/password");
const { signToken } = require("../lib/token");
const { ApiError } = require("../lib/http");
const { clean } = require("../lib/sanitize");

async function customerSignup({ body }) {
  const { name, email, mobile, password } = body;

  if (!name || !email || !mobile || !password) {
    throw new ApiError(400, "Please fill all required fields");
  }

  const db = readDB();

  const exists = db.customers.find((c) => c.email === email || c.mobile === mobile);
  if (exists) {
    throw new ApiError(409, "Account already exists with this email/mobile");
  }

  const customer = {
    id: db.nextIds.customer++,
    name: clean(name),
    email: clean(email),
    mobile: clean(mobile, 20),
    password: hashPassword(password),
  };

  db.customers.push(customer);
  writeDB(db);

  return { message: "Customer account created successfully" };
}

async function customerLogin({ body }) {
  const { emailOrMobile, password } = body;

  if (!emailOrMobile || !password) {
    throw new ApiError(400, "Please enter email/mobile and password");
  }

  const db = readDB();
  const customer = db.customers.find(
    (c) => c.email === emailOrMobile || c.mobile === emailOrMobile
  );

  if (!customer || !verifyPassword(password, customer.password)) {
    throw new ApiError(401, "Incorrect email/mobile or password");
  }

  const token = signToken({ id: customer.id, role: "customer", email: customer.email });

  return {
    message: "Login successful",
    token,
    user: { id: customer.id, name: customer.name, email: customer.email },
  };
}

async function sellerSignup({ body }) {
  const { owner, shop, email, mobile, city, category, password } = body;

  if (!owner || !shop || !email || !mobile || !city || !category || !password) {
    throw new ApiError(400, "Please complete all seller details");
  }

  const db = readDB();

  const exists = db.sellers.find((s) => s.email === email);
  if (exists) {
    throw new ApiError(409, "Seller already registered with this email");
  }

  const seller = {
    id: db.nextIds.seller++,
    owner: clean(owner),
    shop: clean(shop),
    email: clean(email),
    mobile: clean(mobile, 20),
    city: clean(city),
    category: clean(category),
    password: hashPassword(password),
    status: "Pending Verification",
  };

  db.sellers.push(seller);
  writeDB(db);

  return { message: "Shop registered! Verification process started." };
}

async function sellerLogin({ body }) {
  const { email, password } = body;

  if (!email || !password) {
    throw new ApiError(400, "Please enter seller login details");
  }

  const db = readDB();
  const seller = db.sellers.find((s) => s.email === email);

  if (!seller || !verifyPassword(password, seller.password)) {
    throw new ApiError(401, "Incorrect seller email or password");
  }

  const token = signToken({ id: seller.id, role: "seller", email: seller.email });

  return {
    message: "Seller login successful",
    token,
    user: {
      id: seller.id,
      shop: seller.shop,
      email: seller.email,
      status: seller.status,
    },
  };
}

async function adminLogin({ body }) {
  const { email, password } = body;
  const db = readDB();

  if (!email || email !== db.admin.email) {
    throw new ApiError(401, "Invalid admin credentials");
  }

  let valid = false;

  if (db.admin.password.includes(":")) {
    // already securely hashed
    valid = verifyPassword(password, db.admin.password);
  } else {
    // pehli baar plain-text default password ke saath compare, fir hash karke save
    valid = password === db.admin.password;
    if (valid) {
      db.admin.password = hashPassword(password);
      writeDB(db);
    }
  }

  if (!valid) throw new ApiError(401, "Invalid admin credentials");

  const token = signToken({ id: "admin", role: "admin", email });
  return { message: "Admin login successful", token };
}

module.exports = { customerSignup, customerLogin, sellerSignup, sellerLogin, adminLogin };
