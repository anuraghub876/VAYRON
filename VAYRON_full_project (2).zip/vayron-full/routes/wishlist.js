const { readDB, writeDB } = require("../lib/db");

async function getWishlist({ user }) {
  const db = readDB();
  const ids = db.wishlists[user.id] || [];
  return db.products.filter((p) => ids.includes(p.id));
}

async function toggleWishlist({ user, params }) {
  const productId = Number(params.productId);
  const db = readDB();

  if (!db.wishlists[user.id]) db.wishlists[user.id] = [];
  const list = db.wishlists[user.id];

  const idx = list.indexOf(productId);
  let action;

  if (idx === -1) {
    list.push(productId);
    action = "added";
  } else {
    list.splice(idx, 1);
    action = "removed";
  }

  writeDB(db);
  return { action, wishlist: list };
}

module.exports = { getWishlist, toggleWishlist };
