/*
  VAYRON — Backend + Frontend, ek hi server se
  ------------------------------------------------
  Koi npm install ki zaroorat nahi — sirf Node.js (built-in http, crypto,
  fs modules) use kiya hai. Bas "node server.js" chalao.
*/

const http = require("http");
const path = require("path");
const { URL } = require("url");

const { ApiError, parseBody, sendJSON, serveStatic } = require("./lib/http");
const { verifyToken } = require("./lib/token");

const authRoutes = require("./routes/auth");
const productRoutes = require("./routes/products");
const cartRoutes = require("./routes/cart");
const wishlistRoutes = require("./routes/wishlist");
const orderRoutes = require("./routes/orders");
const sellerRoutes = require("./routes/seller");
const adminRoutes = require("./routes/admin");
const reviewRoutes = require("./routes/reviews");
const storeRoutes = require("./routes/stores");

const PORT = process.env.PORT || 5000;
const PUBLIC_DIR = path.join(__dirname, "public");

/* ---------- ROUTE TABLE ---------- */
// auth: false = koi login nahi chahiye | "customer"/"seller"/"admin" = us role ka login chahiye

const routes = [
  // AUTH
  { method: "POST", path: "/api/auth/customer/signup", auth: false, handler: authRoutes.customerSignup },
  { method: "POST", path: "/api/auth/customer/login", auth: false, handler: authRoutes.customerLogin },
  { method: "POST", path: "/api/auth/seller/signup", auth: false, handler: authRoutes.sellerSignup },
  { method: "POST", path: "/api/auth/seller/login", auth: false, handler: authRoutes.sellerLogin },
  { method: "POST", path: "/api/auth/admin/login", auth: false, handler: authRoutes.adminLogin },

  // PRODUCTS
  { method: "GET", path: "/api/products", auth: false, handler: productRoutes.listProducts },
  { method: "GET", path: "/api/products/seller/mine", auth: "seller", handler: productRoutes.myProducts },
  { method: "GET", path: "/api/products/:id", auth: false, handler: productRoutes.getProduct },
  { method: "POST", path: "/api/products", auth: "seller", handler: productRoutes.addProduct },
  { method: "PUT", path: "/api/products/:id", auth: "seller", handler: productRoutes.updateProduct },
  { method: "DELETE", path: "/api/products/:id", auth: "seller", handler: productRoutes.deleteProduct },

  // REVIEWS
  { method: "GET", path: "/api/products/:id/reviews", auth: false, handler: reviewRoutes.getProductReviews },
  { method: "POST", path: "/api/products/:id/reviews", auth: "customer", handler: reviewRoutes.addReview },

  // STORES (public store profile — products, orders, customers, reviews)
  { method: "GET", path: "/api/stores/:sellerId", auth: false, handler: storeRoutes.getStore },

  // CART
  { method: "GET", path: "/api/cart", auth: "customer", handler: cartRoutes.getCart },
  { method: "POST", path: "/api/cart", auth: "customer", handler: cartRoutes.addToCart },
  { method: "PUT", path: "/api/cart/:productId", auth: "customer", handler: cartRoutes.updateCartItem },
  { method: "DELETE", path: "/api/cart/:productId", auth: "customer", handler: cartRoutes.removeCartItem },
  { method: "DELETE", path: "/api/cart", auth: "customer", handler: cartRoutes.clearCart },

  // WISHLIST
  { method: "GET", path: "/api/wishlist", auth: "customer", handler: wishlistRoutes.getWishlist },
  { method: "POST", path: "/api/wishlist/:productId", auth: "customer", handler: wishlistRoutes.toggleWishlist },

  // ORDERS
  { method: "POST", path: "/api/orders", auth: "customer", handler: orderRoutes.placeOrder },
  { method: "GET", path: "/api/orders", auth: "customer", handler: orderRoutes.myOrders },
  { method: "GET", path: "/api/orders/:id", auth: "customer", handler: orderRoutes.getOrder },

  // SELLER
  { method: "GET", path: "/api/seller/profile", auth: "seller", handler: sellerRoutes.sellerProfile },
  { method: "GET", path: "/api/seller/orders", auth: "seller", handler: sellerRoutes.sellerOrders },
  { method: "GET", path: "/api/seller/dashboard-stats", auth: "seller", handler: sellerRoutes.sellerStats },

  // ADMIN
  { method: "GET", path: "/api/admin/sellers", auth: "admin", handler: adminRoutes.allSellers },
  { method: "PUT", path: "/api/admin/sellers/:id/approve", auth: "admin", handler: adminRoutes.approveSeller },
  { method: "PUT", path: "/api/admin/sellers/:id/reject", auth: "admin", handler: adminRoutes.rejectSeller },
  { method: "GET", path: "/api/admin/products", auth: "admin", handler: adminRoutes.adminProducts },
  { method: "PUT", path: "/api/admin/products/:id/approve", auth: "admin", handler: adminRoutes.approveProduct },
  { method: "PUT", path: "/api/admin/products/:id/reject", auth: "admin", handler: adminRoutes.rejectProduct },
  { method: "GET", path: "/api/admin/stats", auth: "admin", handler: adminRoutes.adminStats },
];

/* ---------- ROUTE MATCHING ---------- */

function compileRoute(route) {
  const paramNames = [];
  const regexStr =
    "^" +
    route.path.replace(/:[^/]+/g, (m) => {
      paramNames.push(m.slice(1));
      return "([^/]+)";
    }) +
    "$";
  return { ...route, regex: new RegExp(regexStr), paramNames };
}

const compiledRoutes = routes.map(compileRoute);

function matchRoute(method, pathname) {
  for (const route of compiledRoutes) {
    if (route.method !== method) continue;
    const match = pathname.match(route.regex);
    if (!match) continue;

    const params = {};
    route.paramNames.forEach((name, i) => {
      params[name] = decodeURIComponent(match[i + 1]);
    });

    return { handler: route.handler, auth: route.auth, params };
  }
  return null;
}

/* ---------- REQUEST HANDLER ---------- */

async function handleApiRequest(req, res, pathname, query) {
  const route = matchRoute(req.method, pathname);
  if (!route) return sendJSON(res, 404, { error: "API route not found" });

  try {
    let body = {};
    if (["POST", "PUT", "DELETE"].includes(req.method)) {
      body = await parseBody(req);
    }

    let user = null;
    if (route.auth) {
      const authHeader = req.headers["authorization"] || "";
      const token = authHeader.startsWith("Bearer ") ? authHeader.slice(7) : null;
      if (!token) throw new ApiError(401, "Login required");

      try {
        user = verifyToken(token);
      } catch (e) {
        throw new ApiError(401, "Invalid or expired token, please login again");
      }

      if (typeof route.auth === "string" && user.role !== route.auth) {
        throw new ApiError(403, `Only ${route.auth} can access this`);
      }
    }

    const result = await route.handler({ req, res, params: route.params, query, body, user });
    sendJSON(res, 200, result);
  } catch (err) {
    const status = err.status || 500;
    if (status === 500) console.error("Server error:", err);
    sendJSON(res, status, { error: err.message || "Something went wrong" });
  }
}

/* ---------- SERVER ---------- */

const server = http.createServer(async (req, res) => {
  // CORS (agar frontend kabhi alag origin/port se chale to bhi kaam kare)
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET,POST,PUT,DELETE,OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");

  if (req.method === "OPTIONS") {
    res.writeHead(204);
    return res.end();
  }

  const parsedUrl = new URL(req.url, `http://${req.headers.host}`);
  const pathname = parsedUrl.pathname;
  const query = Object.fromEntries(parsedUrl.searchParams);

  if (pathname.startsWith("/api/")) {
    return handleApiRequest(req, res, pathname, query);
  }

  // Baaki sab kuch frontend files hai (public/ folder se serve hota hai)
  return serveStatic(PUBLIC_DIR, req, res);
});

server.listen(PORT, () => {
  console.log(`🚀 VAYRON chal raha hai: http://localhost:${PORT}`);
  console.log(`   Homepage: http://localhost:${PORT}/homepage.html`);
});

module.exports = server;
