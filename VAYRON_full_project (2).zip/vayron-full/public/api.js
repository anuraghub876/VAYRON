/*
  VAYRON API HELPER
  ------------------
  Ye file backend (same server) se baat karti hai.
  Sab function names "api" prefix ke saath hai taaki tumhare
  existing page functions (jaise addProduct, customerLogin) se clash na ho.
*/

const API_BASE = "/api"; // same server se serve ho raha hai isliye relative path

/* ---------- TOKEN HELPERS ---------- */

function getToken() {
  return localStorage.getItem("vayron_token");
}

function setToken(token) {
  localStorage.setItem("vayron_token", token);
}

function clearToken() {
  localStorage.removeItem("vayron_token");
  localStorage.removeItem("vayron_role");
  localStorage.removeItem("vayron_user");
}

function getRole() {
  return localStorage.getItem("vayron_role"); // "customer" | "seller" | "admin"
}

function getCurrentUser() {
  try {
    return JSON.parse(localStorage.getItem("vayron_user") || "null");
  } catch (e) {
    return null;
  }
}

function isLoggedIn() {
  return !!getToken();
}

/* ---------- CORE FETCH WRAPPER ---------- */

async function apiCall(path, { method = "GET", body, auth = true } = {}) {
  const headers = { "Content-Type": "application/json" };

  if (auth && getToken()) {
    headers["Authorization"] = "Bearer " + getToken();
  }

  const res = await fetch(API_BASE + path, {
    method,
    headers,
    body: body ? JSON.stringify(body) : undefined,
  });

  const data = await res.json().catch(() => ({}));

  if (!res.ok) {
    throw new Error(data.error || "Something went wrong");
  }

  return data;
}

/* ---------- AUTH ---------- */

async function apiCustomerSignup({ name, email, mobile, password }) {
  return apiCall("/auth/customer/signup", {
    method: "POST",
    auth: false,
    body: { name, email, mobile, password },
  });
}

async function apiCustomerLogin({ emailOrMobile, password }) {
  const data = await apiCall("/auth/customer/login", {
    method: "POST",
    auth: false,
    body: { emailOrMobile, password },
  });
  setToken(data.token);
  localStorage.setItem("vayron_role", "customer");
  localStorage.setItem("vayron_user", JSON.stringify(data.user));
  return data;
}

async function apiSellerSignup(payload) {
  return apiCall("/auth/seller/signup", { method: "POST", auth: false, body: payload });
}

async function apiSellerLogin({ email, password }) {
  const data = await apiCall("/auth/seller/login", {
    method: "POST",
    auth: false,
    body: { email, password },
  });
  setToken(data.token);
  localStorage.setItem("vayron_role", "seller");
  localStorage.setItem("vayron_user", JSON.stringify(data.user));
  return data;
}

async function apiAdminLogin({ email, password }) {
  const data = await apiCall("/auth/admin/login", {
    method: "POST",
    auth: false,
    body: { email, password },
  });
  setToken(data.token);
  localStorage.setItem("vayron_role", "admin");
  return data;
}

function apiLogout() {
  clearToken();
  window.location.href = "login.html";
}

/* ---------- PRODUCTS ---------- */

async function apiGetProducts({ category, search } = {}) {
  const params = new URLSearchParams();
  if (category) params.set("category", category);
  if (search) params.set("search", search);
  return apiCall("/products?" + params.toString(), { auth: false });
}

async function apiGetProduct(id) {
  return apiCall("/products/" + id, { auth: false });
}

async function apiAddProduct(productData) {
  return apiCall("/products", { method: "POST", body: productData });
}

async function apiGetMyProducts() {
  return apiCall("/products/seller/mine");
}

async function apiUpdateProduct(id, updates) {
  return apiCall("/products/" + id, { method: "PUT", body: updates });
}

async function apiDeleteProduct(id) {
  return apiCall("/products/" + id, { method: "DELETE" });
}

/* ---------- CART ---------- */

async function apiGetCart() {
  return apiCall("/cart");
}

async function apiAddToCart({ productId, size, color, quantity = 1 }) {
  return apiCall("/cart", { method: "POST", body: { productId, size, color, quantity } });
}

async function apiChangeCartQty(productId, quantity, size, color) {
  return apiCall("/cart/" + productId, { method: "PUT", body: { quantity, size, color } });
}

async function apiRemoveFromCart(productId) {
  return apiCall("/cart/" + productId, { method: "DELETE" });
}

async function apiClearCart() {
  return apiCall("/cart", { method: "DELETE" });
}

/* ---------- WISHLIST ---------- */

async function apiGetWishlist() {
  return apiCall("/wishlist");
}

async function apiToggleWishlist(productId) {
  return apiCall("/wishlist/" + productId, { method: "POST" });
}

/* ---------- ORDERS ---------- */

async function apiPlaceOrder({ address, paymentMethod }) {
  return apiCall("/orders", { method: "POST", body: { address, paymentMethod } });
}

async function apiGetMyOrders() {
  return apiCall("/orders");
}

/* ---------- SELLER DASHBOARD ---------- */

async function apiGetSellerProfile() {
  return apiCall("/seller/profile");
}

async function apiGetSellerOrders() {
  return apiCall("/seller/orders");
}

async function apiGetSellerStats() {
  return apiCall("/seller/dashboard-stats");
}

/* ---------- REVIEWS ---------- */

async function apiGetProductReviews(productId) {
  return apiCall("/products/" + productId + "/reviews", { auth: false });
}

async function apiAddReview(productId, rating, text) {
  return apiCall("/products/" + productId + "/reviews", {
    method: "POST",
    body: { rating, text },
  });
}

/* ---------- STORE PROFILE ---------- */

async function apiGetStore(sellerId) {
  return apiCall("/stores/" + sellerId, { auth: false });
}

/* ---------- ADMIN ---------- */

async function apiGetAllSellers() {
  return apiCall("/admin/sellers");
}

async function apiApproveSeller(id) {
  return apiCall(`/admin/sellers/${id}/approve`, { method: "PUT" });
}

async function apiRejectSeller(id) {
  return apiCall(`/admin/sellers/${id}/reject`, { method: "PUT" });
}

async function apiGetAdminProducts(status) {
  return apiCall("/admin/products" + (status ? "?status=" + status : ""));
}

async function apiApproveProduct(id) {
  return apiCall(`/admin/products/${id}/approve`, { method: "PUT" });
}

async function apiRejectProduct(id) {
  return apiCall(`/admin/products/${id}/reject`, { method: "PUT" });
}

async function apiGetAdminStats() {
  return apiCall("/admin/stats");
}
