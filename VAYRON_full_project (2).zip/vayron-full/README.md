# VAYRON — Full Project (Backend + Frontend connected)

## Kaise chalana hai (2 steps)

1. **Node.js** install karo (nodejs.org → LTS). Ek baar.
2. Is folder me terminal kholo aur chalao:
   ```
   node server.js
   ```
   (Windows me `start.bat` pe double-click bhi kar sakte ho.)

**Koi `npm install` nahi chahiye** — backend me kisi external package ki zaroorat nahi hai.

Phir browser me kholo: **http://localhost:5000**

> ⚠️ HTML files ko double-click karke (file://) mat kholo — hamesha `http://localhost:5000/...` se kholo,
> warna login/cart API calls kaam nahi karengi.

## Login details

| Role | Kaise |
|---|---|
| Admin | `http://localhost:5000/admin.html` → `admin@vayron.com` / `admin123` (**pehli baar login ke baad password khud hash ho jata hai; production me badal do**) |
| Customer | `login.html` se signup karo |
| Seller | `login.html` se seller signup karo → Admin se approve karwao |

## Poora flow (kaise kaam karta hai)

1. Seller signup → **Admin** panel me "Pending Sellers" me dikhta hai → Approve
2. Seller login → Dashboard → "Add New Product" → product **pending** status me jata hai
3. **Admin** → "Pending Product Approvals" → Approve → ab product homepage/men/women pe sabko dikhta hai
4. Customer login → wishlist / cart (server pe save) → cart.html → pincode verify → Place Order
5. Seller dashboard me sales/orders/products ke real numbers dikhte hain

## Folder structure

```
server.js          → main server (API + frontend dono serve karta hai)
db.json            → database (JSON file) — sab data yahin save hota hai
lib/               → token, password hashing, sanitize, http helpers
routes/            → auth, products, cart, wishlist, orders, seller, admin
public/            → tumhare saare HTML pages + api.js (frontend↔backend bridge)
_old_drafts/       → 2 purane homepage drafts (ab use nahi ho rahe, safe rakhe hai)
CORRECTIONS.md     → maine kya-kya fix/change kiya (zaroor padho)
```

## Environment variables (optional)

- `PORT` — default 5000
- `JWT_SECRET` — **deploy karte waqt zaroor set karo** (login tokens isse sign hote hain)

## Database reset

`db.json` me `customers`, `sellers`, `orders`, `carts`, `wishlists` ko khali (`[]` / `{}`) kar do.
`products` me 18 seed products hai (tumhare pages se nikale hue, images ke saath).
